package registration;

public class Login {
    private String enteredUsername;
    private String enteredPassword;

    //  Check Username 
    // This method checks if the username is valid.
    // Valid usernames must contain an underscore and be 5 characters or less.
    public static boolean checkUserName(String userName) {
        return userName != null && userName.contains("_") && userName.length() <= 5;
    }

    //  Check Password 
    // This method checks if the password meets the required complexity.
    // Password must be at least 8 characters long, contain at least one uppercase letter,
    // one number, and one special character (e.g. !, @, #, etc.).
    public static boolean checkPasswordComplexity(String password) {
        if (password == null || password.length() < 8) return false;
        boolean hasNum = false, hasCap = false, hasSchar = false;
        
        // Loop through each character in the password to check for required conditions
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCap = true; // Check for capital letter
            if (Character.isDigit(c)) hasNum = true;     // Check for number
            if (!Character.isLetterOrDigit(c)) hasSchar = true; // Check for special character
        }
        
        // Return true if all conditions are met
        return hasNum && hasCap && hasSchar;
    }

    // Check Cell Phone 
    // This method checks if the phone number follows the correct format.
    // It should start with +27 (South Africa's country code) followed by 9 digits.
    public static boolean checkCellPhoneNumber(String num) {
        return num != null && num.matches("^\\+27[0-9]{9}$");
    }

    // Register User
    // This method handles user registration.
    // It checks if the username, password, and phone number are valid,
    // and returns a message based on the validation result.
    public String registerUser(String username, String password, String phoneNumber) {
        boolean usernameValid = checkUserName(username);      // Validate username
        boolean passwordValid = checkPasswordComplexity(password); // Validate password
        boolean phoneValid = checkCellPhoneNumber(phoneNumber);   // Validate phone number

        // Return specific error messages based on validation failures
        if (!usernameValid) {
            return "Username is not correctly formatted. Please ensure your username contains an underscore and is no more than 5 characters long.";
        } else if (!passwordValid) {
            return "Password is not correctly formatted. Please ensure it contains at least 8 characters, a capital letter, a number, and a special character.";
        } else if (!phoneValid) {
            return "Phone number is incorrectly formatted. It must start with +27 followed by 9 digits.";
        } else {
            return "Registration successful! Your username, password, and phone number have been successfully added.";
        }
    }

    //  Login Check 
    // This method checks if the entered username and password match the registered details.
    // It returns true if both are correct, otherwise false.
    public boolean loginUser() {
        return enteredUsername != null && enteredPassword != null &&
                enteredUsername.equals(Registration.getUserName()) &&
                enteredPassword.equals(Registration.getPassword());
    }

    // Login Status 
    // This method returns a message indicating whether the login attempt was successful or not.
    // If successful, it greets the user with their first and last name.
    public String returnLoginStatus() {
        if (loginUser()) {
            return "Welcome " + Registration.getFirstName() + " " + Registration.getLastName() + ", it’s great to see you again!";
        } else {
            return "Incorrect username or password. Please try again.";
        }
    }

    // Setters for login attempt 
    // These methods are used to set the username and password that the user enters during login.
    public void setEnteredUsername(String username) { this.enteredUsername = username; }
    public void setEnteredPassword(String password) { this.enteredPassword = password; }
}
